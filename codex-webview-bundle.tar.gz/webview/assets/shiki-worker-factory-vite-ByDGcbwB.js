const r=""+new URL("worker-CJ6-3-tZ.js",import.meta.url).href;function e(){return new Worker(r,{type:"module"})}export{e as shikiWorkerFactoryVite};
