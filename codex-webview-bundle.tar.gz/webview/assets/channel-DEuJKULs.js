import{aw as o,ax as n}from"./index-Vu9-Y18p.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
